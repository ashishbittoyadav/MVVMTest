package com.headspire.mvvmtest;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.headspire.mvvmtest.adapter.AdapterList;
import com.headspire.mvvmtest.model.ItemModel;
import com.headspire.mvvmtest.repository.ItemRepository;
import com.headspire.mvvmtest.viewmodel.ItemViewModel;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mrecyclerView;
    private AdapterList adapterList;
    private ItemViewModel itemViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mrecyclerView=findViewById(R.id.myrecyclerview);
    }
}
